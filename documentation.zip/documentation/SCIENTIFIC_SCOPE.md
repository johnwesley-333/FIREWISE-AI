# Scientific Scope and Limitations

FIREWISE AI is a research-support prototype for organizing and exploring microgravity combustion literature. The bundled catalogue contains qualitative summaries only. Uploaded PDFs are text-extracted and searched; no validated numerical dataset or predictive fire model is included. Programme comparison is qualitative. The system is not certified for spacecraft design, fire detection, fire suppression control, or operational risk prediction. Always verify claims against the original NASA publication and cite its page.
