# AI Use Disclosure

FIREWISE AI uses a generative AI model (Gemini, when configured) to synthesize answers from text excerpts retrieved from the project's indexed research documents. Retrieval is implemented with keyword overlap; it is not a trained scientific model. AI output may be incomplete or incorrect and must be checked against the original sources. The frontend, backend scaffolding, CSS and documentation were developed with AI assistance and reviewed/assembled by the project team.
